//
//  ViewController.h
//  CoreDataCouresera
//
//  Created by Eric on 12/22/15.
//  Copyright © 2015 Eric. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

