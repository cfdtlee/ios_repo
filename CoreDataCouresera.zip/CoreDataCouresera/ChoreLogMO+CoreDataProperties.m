//
//  ChoreLogMO+CoreDataProperties.m
//  CoreDataCouresera
//
//  Created by Eric on 1/1/16.
//  Copyright © 2016 Eric. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "ChoreLogMO+CoreDataProperties.h"

@implementation ChoreLogMO (CoreDataProperties)

@dynamic when;
@dynamic chore_done;
@dynamic person_who_did_it;

@end
