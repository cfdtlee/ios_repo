//
//  ChoreLogMO.h
//  CoreDataCouresera
//
//  Created by Eric on 1/1/16.
//  Copyright © 2016 Eric. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class ChoreMO, PersonMO;

NS_ASSUME_NONNULL_BEGIN

@interface ChoreLogMO : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "ChoreLogMO+CoreDataProperties.h"
