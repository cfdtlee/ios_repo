//
//  PersonMO.m
//  CoreDataCouresera
//
//  Created by Eric on 12/31/15.
//  Copyright © 2015 Eric. All rights reserved.
//

#import "PersonMO.h"
#import "ChoreLogMO.h"

@implementation PersonMO

// Insert code here to add functionality to your managed object subclass

- (NSString *)description
{
    return self.person_name;
}

@end
