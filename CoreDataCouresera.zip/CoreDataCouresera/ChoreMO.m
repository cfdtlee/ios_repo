//
//  ChoreMO.m
//  CoreDataCouresera
//
//  Created by Eric on 12/31/15.
//  Copyright © 2015 Eric. All rights reserved.
//

#import "ChoreMO.h"
#import "ChoreLogMO.h"

@implementation ChoreMO

// Insert code here to add functionality to your managed object subclass
- (NSString *)description
{
    return self.chore_name;
}
@end
