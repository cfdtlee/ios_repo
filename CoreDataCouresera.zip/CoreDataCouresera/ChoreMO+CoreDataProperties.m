//
//  ChoreMO+CoreDataProperties.m
//  CoreDataCouresera
//
//  Created by Eric on 12/31/15.
//  Copyright © 2015 Eric. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "ChoreMO+CoreDataProperties.h"

@implementation ChoreMO (CoreDataProperties)

@dynamic chore_name;
@dynamic chore_log;

@end
