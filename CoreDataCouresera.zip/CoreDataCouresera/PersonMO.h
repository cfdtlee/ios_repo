//
//  PersonMO.h
//  CoreDataCouresera
//
//  Created by Eric on 12/31/15.
//  Copyright © 2015 Eric. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class ChoreLogMO ;

NS_ASSUME_NONNULL_BEGIN

@interface PersonMO : NSManagedObject

// Insert code here to declare functionality of your managed object subclass
- (NSString *)description;
@end

NS_ASSUME_NONNULL_END

#import "PersonMO+CoreDataProperties.h"
